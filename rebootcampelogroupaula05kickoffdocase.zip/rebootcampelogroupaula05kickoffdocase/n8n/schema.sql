-- ============================================================
-- Schema mock para automação de atendimento com IA (n8n + RAG)
-- Compatível com PostgreSQL e MySQL (pequenos ajustes indicados)
-- ============================================================

-- 1. Fila de entrada de tickets (o que o n8n consome)
CREATE TABLE tickets_atendimento (
    ticket_id             VARCHAR(20) PRIMARY KEY,
    customer_id           VARCHAR(20) NOT NULL,
    canal_entrada         VARCHAR(30) NOT NULL,       -- WhatsApp, E-mail, ChatBot, Telefone, Reclame Aqui
    categoria_problema    VARCHAR(50),                -- rótulo real (só pra validar a classificação da IA, não repassar pro agente)
    texto_cliente         TEXT NOT NULL,
    status_processamento  VARCHAR(20) DEFAULT 'novo', -- novo | processado | escalado_humano
    criado_em             TIMESTAMP NOT NULL          -- MySQL: DATETIME
);

-- 2. Base de conhecimento (fonte do RAG)
CREATE TABLE base_conhecimento (
    id                    VARCHAR(10) PRIMARY KEY,
    categoria             VARCHAR(50) NOT NULL,
    pergunta_referencia   TEXT NOT NULL,
    resposta_padrao       TEXT NOT NULL,
    tags                  VARCHAR(200)                -- separado por vírgula; vira filtro/embedding depois
);

-- 3. Lookup de pedidos (pro fluxo "onde está meu pedido")
CREATE TABLE pedidos_rastreio (
    order_id              VARCHAR(20) PRIMARY KEY,
    customer_id           VARCHAR(20) NOT NULL,
    data_pedido           TIMESTAMP NOT NULL,
    status_pagamento      VARCHAR(20),
    devolvido             BOOLEAN,                    -- MySQL: TINYINT(1)
    tempo_entrega_real    INT,                         -- dias
    status_rastreio       VARCHAR(30),                -- Postado | Em trânsito | Saiu para entrega | Entregue | Devolvido | Pagamento pendente
    transportadora        VARCHAR(30)
);

-- 4. Log de execução do agente (o n8n grava aqui a cada rodada)
CREATE TABLE log_execucao_agente (
    log_id                SERIAL PRIMARY KEY,          -- MySQL: INT AUTO_INCREMENT PRIMARY KEY
    ticket_id             VARCHAR(20) REFERENCES tickets_atendimento(ticket_id),
    categoria_detectada   VARCHAR(50),
    confianca_pct         DECIMAL(5,2),
    resposta_gerada       TEXT,
    precisou_humano       BOOLEAN,                     -- MySQL: TINYINT(1)
    tempo_resposta_seg    INT,
    custo_estimado_reais  DECIMAL(6,2),
    criado_em             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Módulo C — Motor de priorização de margem
-- ============================================================

-- 5. Oportunidades (insumo do motor — hoje só existe em markdown/HTML)
CREATE TABLE oportunidades (
    id                       VARCHAR(10) PRIMARY KEY,
    nome                     VARCHAR(100) NOT NULL,
    area                     VARCHAR(30),                -- atendimento | marketing | clientes | estoque
    impacto_min_reais        DECIMAL(12,2),
    impacto_max_reais        DECIMAL(12,2),
    impacto_medio_reais      DECIMAL(12,2),
    esforco_nivel            INT,                        -- 1 (baixíssimo) a 5 (alto)
    janela_dias              INT,                        -- dias até captura do impacto
    tipo                     VARCHAR(20),                -- quick_win | estruturante
    nota_estrategica_manual  INT                         -- 1-5, só usada quando impacto_medio_reais = 0
);

-- 6. Resultado do motor de priorização (o n8n grava aqui a cada rodada)
CREATE TABLE oportunidades_priorizadas (
    execucao_id           SERIAL PRIMARY KEY,
    oportunidade_id        VARCHAR(10) REFERENCES oportunidades(id),
    impacto_tier          INT,
    facilidade_tier       INT,
    velocidade_tier       INT,
    score                 DECIMAL(5,1),
    justificativa_ia      TEXT,                          -- gerada pelo nó de LLM
    criado_em             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Módulo D — Gerador de relatório executivo semanal
-- ============================================================

-- 7. Snapshot semanal de KPIs (1 linha nova por semana, alimenta o cálculo de variação)
CREATE TABLE kpis_semanais (
    semana_referencia            VARCHAR(10) PRIMARY KEY,   -- formato '2026-W03'
    receita_liquida              DECIMAL(12,2),
    margem_pct                   DECIMAL(5,2),
    cac_medio                    DECIMAL(6,2),
    csat_medio                   DECIMAL(3,2),
    custo_atendimento_semanal    DECIMAL(10,2),
    skus_criticos                INT,
    tickets_automatizados_pct    DECIMAL(5,2)
);

-- 8. Status de execução das iniciativas aprovadas (projetado vs realizado)
CREATE TABLE iniciativas_status (
    id                        VARCHAR(10) REFERENCES oportunidades(id),
    impacto_projetado_reais   DECIMAL(12,2),
    impacto_realizado_reais   DECIMAL(12,2),
    pct_execucao              INT,             -- 0-100
    status                    VARCHAR(20),     -- nao_iniciada | em_andamento | concluida | bloqueada
    atualizado_em             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 9. Limites de alerta — o que conta como "fora do padrão" por KPI
CREATE TABLE alertas_thresholds (
    kpi_nome      VARCHAR(40) PRIMARY KEY,
    limite_min    DECIMAL(10,2),               -- NULL se não se aplica
    limite_max    DECIMAL(10,2),               -- NULL se não se aplica
    direcao       VARCHAR(30)                  -- abaixo_de_min_e_alerta | acima_de_max_e_alerta
);

-- 10. Relatórios gerados (histórico do que o LLM produziu)
CREATE TABLE relatorios_gerados (
    relatorio_id          SERIAL PRIMARY KEY,
    semana_referencia     VARCHAR(10),
    texto_relatorio       TEXT,
    gerado_em             TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
